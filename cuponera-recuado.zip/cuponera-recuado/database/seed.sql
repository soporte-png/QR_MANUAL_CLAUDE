-- database/seed.sql
-- Script para crear usuarios iniciales con contraseñas hasheadas

-- Contraseñas:
-- admin: admin123 -> hash bcrypt
-- operador: operador123 -> hash bcrypt

INSERT INTO usuarios (username, password_hash, role) VALUES
    ('admin', '$2b$10$K5z.qQ5rXxH5X5X5X5X5XeK5z.qQ5rXxH5X5X5X5X5XeK5z.qQ5rX', 'admin'),
    ('operador', '$2b$10$K5z.qQ5rXxH5X5X5X5X5XeK5z.qQ5rXxH5X5X5X5X5XeK5z.qQ5rX', 'operador')
ON CONFLICT (username) DO NOTHING;

-- Nota: Estos son hashes de ejemplo. El script create-users.js generará los hashes reales
-- cuando el contenedor del backend se inicie por primera vez.
