-- Base de datos: cuponera_recaudo

-- Tabla de usuarios
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'operador')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de configuración (una sola fila)
CREATE TABLE configuracion (
    id INTEGER PRIMARY KEY DEFAULT 1,
    gln_base VARCHAR(13) NOT NULL DEFAULT '0000000024602',
    nombre_empresa VARCHAR(255) NOT NULL DEFAULT 'NARANJO AZCARATE Y ASOCIADOS SAS',
    documento_base VARCHAR(10) NOT NULL DEFAULT '0000000000',
    cuenta_recaudo VARCHAR(50) NOT NULL DEFAULT '256940842',
    numero_acuerdo_base INTEGER NOT NULL DEFAULT 56,
    logo_empresa TEXT, -- Base64
    logo_app TEXT, -- Base64
    logo_login TEXT, -- Base64
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT single_config CHECK (id = 1)
);

-- Tabla de consecutivos
CREATE TABLE consecutivos (
    id INTEGER PRIMARY KEY DEFAULT 1,
    numero_acuerdo BIGINT NOT NULL DEFAULT 56,
    numero_obligacion NUMERIC(30) NOT NULL DEFAULT 29039000003930057744,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT single_consecutivo CHECK (id = 1)
);

-- Tabla de cupones generados
CREATE TABLE cupones (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    cedula VARCHAR(10) NOT NULL,
    valor VARCHAR(8) NOT NULL,
    fecha_limite DATE NOT NULL,
    fecha_generacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    numero_acuerdo VARCHAR(50),
    numero_obligacion VARCHAR(50),
    payload TEXT NOT NULL,
    CONSTRAINT fk_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Índices para mejorar rendimiento
CREATE INDEX idx_cupones_cedula ON cupones(cedula);
CREATE INDEX idx_cupones_fecha_generacion ON cupones(fecha_generacion);
CREATE INDEX idx_cupones_usuario ON cupones(usuario_id);
CREATE INDEX idx_cupones_nombre ON cupones(nombre);

-- Insertar datos iniciales
INSERT INTO usuarios (username, password_hash, role) VALUES
    ('admin', '$2b$10$rKvFJElY4bXH.LhN9HvZ4OGXqmXZqXqXqXqXqXqXqXqXqXqXqX', 'admin'),
    ('operador', '$2b$10$rKvFJElY4bXH.LhN9HvZ4OGXqmXZqXqXqXqXqXqXqXqXqXqXqX', 'operador');

INSERT INTO configuracion (id) VALUES (1);
INSERT INTO consecutivos (id) VALUES (1);

-- Trigger para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_usuarios_updated_at
    BEFORE UPDATE ON usuarios
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_configuracion_updated_at
    BEFORE UPDATE ON configuracion
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_consecutivos_updated_at
    BEFORE UPDATE ON consecutivos
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
