// create-users.js - Script para crear usuarios con contraseñas hasheadas
const bcrypt = require('bcrypt');
const { Pool } = require('pg');
require('dotenv').config();

// Esperar a que la base de datos esté lista
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitForDatabase(pool, maxRetries = 10) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            await pool.query('SELECT 1');
            console.log('✅ Conexión a base de datos exitosa');
            return true;
        } catch (error) {
            console.log(`⏳ Esperando conexión a base de datos... (intento ${i + 1}/${maxRetries})`);
            await sleep(2000);
        }
    }
    throw new Error('No se pudo conectar a la base de datos');
}

async function createUsers() {
    const pool = new Pool({
        user: process.env.DB_USER || 'postgres',
        host: process.env.DB_HOST || 'db',
        database: process.env.DB_NAME || 'cuponera_recaudo',
        password: process.env.DB_PASSWORD || 'postgres123',
        port: process.env.DB_PORT || 5432,
    });

    try {
        await waitForDatabase(pool);

        // Hashear contraseñas
        const adminPasswordHash = await bcrypt.hash('admin123', 10);
        const operadorPasswordHash = await bcrypt.hash('operador123', 10);

        // Insertar usuarios
        await pool.query(`
            INSERT INTO usuarios (username, password_hash, role) 
            VALUES 
                ('admin', $1, 'admin'),
                ('operador', $2, 'operador')
            ON CONFLICT (username) DO UPDATE 
            SET password_hash = EXCLUDED.password_hash
        `, [adminPasswordHash, operadorPasswordHash]);

        console.log('✅ Usuarios creados exitosamente:');
        console.log('   - admin / admin123 (rol: admin)');
        console.log('   - operador / operador123 (rol: operador)');

        await pool.end();
    } catch (error) {
        console.error('❌ Error al crear usuarios:', error);
        await pool.end();
        process.exit(1);
    }
}

createUsers();
